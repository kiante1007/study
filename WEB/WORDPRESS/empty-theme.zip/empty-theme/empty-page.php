<?php get_header(); ?>



<?php get_footer(); ?>

<?php echo get_stylesheet_directory_uri();?>