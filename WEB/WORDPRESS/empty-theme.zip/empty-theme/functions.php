<?php

if ( ! function_exists( 'empty_theme_setup' ) ) :
    function empty_theme_setup() {
        add_theme_support( 'title-tag' );
        add_theme_support( 'post-thumbnails' );

        /*
        * Switch default core markup for search form, comment form, and comments
        * to output valid HTML5.
        */
        add_theme_support(
            'html5',
            array(
                'search-form',
                'comment-form',
                'comment-list',
                'gallery',
                'caption',
                'script',
                'style',
            )
        );
    }
endif;
add_action( 'after_setup_theme', 'empty_theme_setup' );

/**
 * Enqueue scripts and styles.
 */
wp_enqueue_script('jquery');
function my_enqueue() {
    wp_enqueue_style( 'theme-font-css', get_stylesheet_directory_uri().'/fonts/fonts.css', array());
    wp_enqueue_style( 'theme-default-css', get_stylesheet_directory_uri().'/fonts/default.css', array());

    wp_enqueue_style( 'theme-stylesheet-css', get_stylesheet_directory_uri().'/css/stylesheet.css', array());
    wp_enqueue_style( 'theme-responsive-css', get_stylesheet_directory_uri().'/css/responsive.css', array());

    wp_enqueue_script( 'theme-script', get_theme_file_uri( '/js/script.js' ), array(), '', true );
    wp_localize_script( 'theme-script', 'theme_url', array( 'template_url' => get_stylesheet_directory_uri() ) );
    wp_enqueue_style( 'theme-style', get_stylesheet_uri() );
}
add_action( 'wp_enqueue_scripts', 'my_enqueue' );
